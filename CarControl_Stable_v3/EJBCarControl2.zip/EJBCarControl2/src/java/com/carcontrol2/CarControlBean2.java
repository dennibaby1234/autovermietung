package com.carcontrol2;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Stateless(name = "CarControlBean2")
public class CarControlBean2 implements CarControlBean2Remote {

    @PersistenceContext(unitName = "CarControlPU")
    private EntityManager entityManager;

    @Override
    public void addCar(Car car) {
        entityManager.persist(car);
    }

    @Override
    public List<Car> getCars() {
        return entityManager.createQuery("FROM Car", Car.class).getResultList();
    }

    @Override
    public void deleteCar(int carId) {
        Car car = entityManager.find(Car.class, carId);
        if (car != null) {
            entityManager.remove(car);
        } else {
            throw new IllegalArgumentException("Kein Auto mit der ID " + carId + " gefunden.");
        }
    }

    @Override
    public void updateCar(int carId, String model, String color, Short speed) {
        Car car = entityManager.find(Car.class, carId);
        if (car != null) {
            if (model != null && !model.isEmpty()) {
                car.setModel(model);
            }
            if (color != null && !color.isEmpty()) {
                car.setColor(color);
            }
            if (speed != null && speed > 0) {
                car.setSpeed(speed);
            }
            entityManager.merge(car);
        } else {
            throw new IllegalArgumentException("Kein Auto mit der ID " + carId + " gefunden.");
        }
    }

    @Override
    public void addKunde(Kunde kunde) {
        entityManager.persist(kunde);
    }

    @Override
    public List<Kunde> getKunden() {
        return entityManager.createQuery("FROM Kunde", Kunde.class).getResultList();
    }

    @Override
    public void deleteKunde(int kundeId) {
        Kunde kunde = entityManager.find(Kunde.class, kundeId);
        if (kunde != null) {
            // Überprüfen, ob ein Auto diesem Kunden zugewiesen ist
            List<Car> cars = getCars();
            for (Car car : cars) {
                if (car.getKunde() != null && car.getKunde().getId() == kundeId) {
                    car.setKunde(null); // Verbindung trennen
                    car.setVerliehen(false); // Auto nicht mehr verliehen
                    entityManager.merge(car); // Änderungen speichern
                }
            }
            // Kunde löschen
            entityManager.remove(kunde);
        } else {
            throw new IllegalArgumentException("Kein Kunde mit der ID " + kundeId + " gefunden.");
        }
    }

    @Override
    public void updateKunde(int kundeId, String attribute, Object value) {
        Kunde kunde = entityManager.find(Kunde.class, kundeId);
        if (kunde != null) {
            if ("vorname".equalsIgnoreCase(attribute)) {
                kunde.setVorname((String) value);
            } else if ("nachname".equalsIgnoreCase(attribute)) {
                kunde.setNachname((String) value);
            }
            entityManager.merge(kunde);
        } else {
            throw new IllegalArgumentException("Kein Kunde mit der ID " + kundeId + " gefunden.");
        }
    }

    @Override
    public String lendCar(int carId, int kundeId) {
        Car car = entityManager.find(Car.class, carId);
        Kunde kunde = entityManager.find(Kunde.class, kundeId);
        if (car != null && kunde != null && !car.isVerliehen()) {
            car.setKunde(kunde);
            car.setVerliehen(true);
            entityManager.merge(car);
            return "Auto erfolgreich verliehen an " + kunde.getVorname() + " " + kunde.getNachname();
        } else if (car != null && car.isVerliehen()) {
            return "Fehler: Das Auto ist bereits verliehen!";
        } else {
            return "Fehler: Ungültige Auto- oder Kunden-ID.";
        }
    }

    @Override
    public List<Car> zeigeAlleAutos() {
        return entityManager.createQuery("SELECT c FROM Car c", Car.class).getResultList();
    }

    @Override
    public List<Kunde> zeigeAlleKunden() {
        return entityManager.createQuery("SELECT k FROM Kunde k", Kunde.class).getResultList();
    }
}
