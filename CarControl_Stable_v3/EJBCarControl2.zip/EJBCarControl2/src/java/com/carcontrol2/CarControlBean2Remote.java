package com.carcontrol2;

import java.util.List;
import javax.ejb.Remote;

@Remote
public interface CarControlBean2Remote {

    void addCar(Car car);

    List<Car> getCars();

    void deleteCar(int carId);

    void updateCar(int carId, String model, String color, Short speed);

    void addKunde(Kunde kunde);

    List<Kunde> getKunden();

    void deleteKunde(int kundeId);

    void updateKunde(int kundeId, String attribute, Object value);

    String lendCar(int carId, int kundeId);

    List<Car> zeigeAlleAutos();

    List<Kunde> zeigeAlleKunden();
}
