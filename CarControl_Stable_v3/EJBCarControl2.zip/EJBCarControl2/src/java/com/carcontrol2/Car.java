package com.carcontrol2;
import javax.persistence.*;
import java.io.Serializable;
@Entity
@Table(name = "car")
public class Car implements Serializable {
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @Column(name = "car_id")
   private int id;
   @Column(name = "model", nullable = false)
   private String model;
   @Column(name = "color", nullable = false)
   private String color;

    public void setId(int id) {
        this.id = id;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setSpeed(short speed) {
        this.speed = speed;
    }

    public void setVerliehen(boolean verliehen) {
        this.verliehen = verliehen;
    }

    public void setKunde(Kunde kunde) {
        this.kunde = kunde;
    }

    public int getId() {
        return id;
    }

    public String getModel() {
        return model;
    }

    public String getColor() {
        return color;
    }

    public short getSpeed() {
        return speed;
    }

    public boolean isVerliehen() {
        return verliehen;
    }

    public Kunde getKunde() {
        return kunde;
    }
   @Column(name = "speed", nullable = false)
   private short speed;
   @Column(name = "verliehen", nullable = false)
   private boolean verliehen;
   @ManyToOne
   @JoinColumn(name = "kunde_id", nullable = true)
   private Kunde kunde;
   public Car() { }
   public Car(String model, String color, short speed) {
       this.model = model;
       this.color = color;
       this.speed = speed;
   }
  
}



   

