package com.carcontrol2;
import javax.persistence.*;
import java.io.Serializable;
@Entity
@Table(name = "kunde")
public class Kunde implements Serializable {
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @Column(name = "kunde_id")
   private int id;
   @Column(name = "vorname", nullable = false)
   private String vorname;
   @Column(name = "nachname", nullable = false)
   private String nachname;
   public Kunde() { }
   public Kunde(String vorname, String nachname) {
       this.vorname = vorname;
       this.nachname = nachname;
   }
   // Getters and Setters

    public void setId(int id) {
        this.id = id;
    }

    public void setVorname(String vorname) {
        this.vorname = vorname;
    }

    public void setNachname(String nachname) {
        this.nachname = nachname;
    }

    public int getId() {
        return id;
    }

    public String getVorname() {
        return vorname;
    }

    public String getNachname() {
        return nachname;
    }
}


